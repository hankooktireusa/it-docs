param()

Write-Host "Generate INSERTs for HKTPWD.HT_PO_MASK`n"

function Prompt-Required {
    param(
        [string]$Label
    )

    while ($true) {
        $value = Read-Host $Label
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value.Trim()
        }
        Write-Host "$Label is required. Please enter a value.`n"
    }
}

function Prompt-YesNo {
    param(
        [string]$Label,
        [string]$Default = "N"
    )

    $Default = $Default.ToUpper()
    while ($true) {
        $prompt = "$Label (Y/N) [$Default]"
        $choice = (Read-Host $prompt).Trim().ToUpper()

        if ([string]::IsNullOrWhiteSpace($choice)) {
            $choice = $Default
        }

        if ($choice -eq "Y") { return $true }
        if ($choice -eq "N") { return $false }

        Write-Host "Please enter Y or N.`n"
    }
}

function Select-RegexPattern {
    param(
        [array]$Patterns
    )

    # If no patterns, fall back to manual entry
    if (-not $Patterns -or $Patterns.Count -eq 0) {
        Write-Host "No pattern file found or it is empty. Enter regex manually."
        $manual = Prompt-Required "REGEX_PATTERN"
        return @{
            Pattern = $manual
            SuggestedDescription = $null
        }
    }

    Write-Host "Select a REGEX pattern template:"
    $index = 1
    foreach ($p in $Patterns) {
        Write-Host ("{0}) {1}" -f $index, $p.label)
        $index++
    }
    Write-Host "0) Enter custom regex"

    $maxIndex = $Patterns.Count

    while ($true) {
        $choiceStr = Read-Host "Choose pattern number"
        [int]$choice = -1
        if ([int]::TryParse($choiceStr, [ref]$choice)) {
            if ($choice -ge 0 -and $choice -le $maxIndex) {
                break
            }
        }
        Write-Host "Please enter a number between 0 and $maxIndex.`n"
    }

    if ($choice -eq 0) {
        # Custom regex
        $manual = Prompt-Required "REGEX_PATTERN"
        return @{
            Pattern = $manual
            SuggestedDescription = $null
        }
    }

    # Template-based regex
    $patternDef = $Patterns[$choice - 1]
    $patternStr = $patternDef.template
    $descStr    = $patternDef.defaultDescription

    foreach ($paramDef in $patternDef.parameters) {
        $name   = $paramDef.name
        $prompt = $paramDef.prompt

        $value = $null
        while ([string]::IsNullOrWhiteSpace($value)) {
            $value = Read-Host $prompt
            if ([string]::IsNullOrWhiteSpace($value)) {
                Write-Host "Value is required for $name.`n"
            }
        }
        $value = $value.Trim()

        # Replace the full placeholder, e.g. "__X__", "__Y__", "__PREFIX__"
        $placeholder = "__{0}__" -f $name

        $patternStr = $patternStr.Replace($placeholder, $value)

        if ($descStr) {
            $descStr = $descStr.Replace($placeholder, $value)
        }
    }

    Write-Host ""
    Write-Host "Generated regex: $patternStr"
    $use = Prompt-YesNo "Use this regex?"

    if (-not $use) {
        $manual = Prompt-Required "REGEX_PATTERN (manual override)"
        return @{
            Pattern = $manual
            SuggestedDescription = $null
        }
    }

    return @{
        Pattern = $patternStr
        SuggestedDescription = $descStr
    }
}

# --- Locate and load pattern file (same folder as script) ---
$scriptDir    = Split-Path -Parent $MyInvocation.MyCommand.Path
$patternFile  = Join-Path $scriptDir "po_patterns.json"

$patternDefs = @()
if (Test-Path $patternFile) {
    try {
        $json = Get-Content $patternFile -Raw
        $patternDefs = $json | ConvertFrom-Json
    }
    catch {
        Write-Warning "Failed to read or parse $patternFile. Falling back to manual regex entry."
        $patternDefs = @()
    }
} else {
    Write-Host "Pattern file not found at $patternFile. You can create it later; using manual regex entry for now."
}

# ============================================================
# Prompt order:
# 1) BILLTO
# 2) SHIPTO(S)
# 3) REGEX (via template/custom)
# 4) DESCRIPTION (use suggested? else custom)
# 5) Other optional params
# ============================================================

# 1) BILLTO (required)
$billto = Prompt-Required "BILLTOCD"

# 2) SHIPTO(S) (optional, can be blank or comma-separated)
$shiptoRaw = Read-Host "SHIPTOCD (single or comma-separated; blank for NULL)"
if ([string]::IsNullOrWhiteSpace($shiptoRaw)) {
    # Default: single row with SHIPTOCD = NULL
    $shiptoList = @($null)
} else {
    $shiptoList = $shiptoRaw -split "," | ForEach-Object {
        $_.Trim()
    } | Where-Object { $_ -ne "" }

    if (-not $shiptoList) {
        $shiptoList = @($null)
    }
}

# 3) Select regex pattern (template or custom)
$regexInfo = Select-RegexPattern -Patterns $patternDefs
$regexPattern = $regexInfo.Pattern
$defaultRegexDescription = $regexInfo.SuggestedDescription

# 4) REGEX_DESCRIPTION with suggested + Y/N
$regexDescription = $null

if ($defaultRegexDescription) {
    Write-Host ""
    Write-Host "Suggested description: $defaultRegexDescription"
    $useSuggested = Prompt-YesNo "Use suggested description?"
    if ($useSuggested) {
        $regexDescription = $defaultRegexDescription
    }
    else {
        $customDesc = Read-Host "REGEX_DESCRIPTION (blank for NULL)"
        if (-not [string]::IsNullOrWhiteSpace($customDesc)) {
            $regexDescription = $customDesc.Trim()
        }
    }
}
else {
    $customDesc = Read-Host "REGEX_DESCRIPTION (blank for NULL)"
    if (-not [string]::IsNullOrWhiteSpace($customDesc)) {
        $regexDescription = $customDesc.Trim()
    }
}

# --- Defaults for other optional fields ---
$defaultMatchRequired  = "Y"
$defaultPriority       = 100
$defaultUseYN          = "Y"

# 5) Ask if we want to change MATCH_REQUIRED, PRIORITY, USEYN
$changeOtherOptionals = Prompt-YesNo "Do you want to change MATCH_REQUIRED, PRIORITY, or USEYN?"

if ($changeOtherOptionals) {
    # MATCH_REQUIRED
    $matchRequiredInput = Read-Host "MATCH_REQUIRED (blank for default '$defaultMatchRequired')"
    if ([string]::IsNullOrWhiteSpace($matchRequiredInput)) {
        $matchRequired = $defaultMatchRequired
    } else {
        $matchRequired = $matchRequiredInput.Trim()
    }

    # PRIORITY
    $priorityInput = Read-Host "PRIORITY (blank for default $defaultPriority)"
    if ([string]::IsNullOrWhiteSpace($priorityInput)) {
        $priority = $defaultPriority
    } else {
        [int]$tmp = 0
        if ([int]::TryParse($priorityInput, [ref]$tmp)) {
            $priority = $tmp
        } else {
            Write-Warning "Invalid PRIORITY '$priorityInput'; using default $defaultPriority."
            $priority = $defaultPriority
        }
    }

    # USEYN
    $useYNInput = Read-Host "USEYN (blank for default '$defaultUseYN')"
    if ([string]::IsNullOrWhiteSpace($useYNInput)) {
        $useYN = $defaultUseYN
    } else {
        $useYN = $useYNInput.Trim()
    }
}
else {
    # Use defaults
    $matchRequired = $defaultMatchRequired
    $priority      = $defaultPriority
    $useYN         = $defaultUseYN
}

Write-Host "`n-- Generated INSERT statements:`n"

foreach ($shipto in $shiptoList) {

    # SHIPTOCD: NULL or quoted
    if ($null -eq $shipto) {
        $shiptoSql = "NULL"
    } else {
        $shiptoSql = "'$shipto'"
    }

    # REGEX_PATTERN is already chosen
    $regexSql = "q'~$regexPattern~'"

    # REGEX_DESCRIPTION -> PATTERN_DESCRIPTION column: NULL or q'~ ~'
    if ($null -eq $regexDescription) {
        $descSql = "NULL"
    } else {
        $descSql = "q'~$regexDescription~'"
    }

    $sql = @"
INSERT INTO HKTPWD.HT_PO_MASK (BILLTOCD, SHIPTOCD, REGEX_PATTERN, PATTERN_DESCRIPTION, MATCH_REQUIRED, PRIORITY, USEYN)
VALUES ('$billto', $shiptoSql, $regexSql, $descSql, '$matchRequired', $priority, '$useYN');
"@

    Write-Host $sql
    Write-Host ""
}

Write-Host "-- Done."
