# 🧩 PO Mask Insert Generator

This PowerShell utility automates the creation of **Oracle SQL INSERT statements** for the `HKTPWD.HT_PO_MASK` table.  
It simplifies the process of generating consistent PO mask records with built-in regex pattern templates, optional defaults, and dynamic user prompts.

---

## ✨ Features at a Glance

- 🧠 **Interactive Prompts** — Step-by-step guided entry for all required and optional fields  
- 🔤 **Smart Regex Templates** — Choose from predefined patterns or enter a custom regex  
- 📝 **Auto-Descriptions** — Suggested human-readable descriptions based on chosen patterns  
- 🧮 **Multi-ShipTo Support** — Generate multiple INSERTs from a single run  
- ⚙️ **Default Handling** — Automatically applies defaults for `MATCH_REQUIRED`, `PRIORITY`, and `USEYN`  
- 💾 **Configurable Templates** — Extendable via `po_patterns.json` for future pattern types  

---

## 📁 Project Structure

po-mask-generator/
├── generate_po_mask_inserts.ps1    # Main interactive PowerShell script  
├── po_patterns.json                # Regex pattern definitions (templates, prompts, and examples)  
└── README.md                       # Project documentation  

---

## ⚙️ Setup (One-Time)

1. **Create a Folder**

   mkdir "C:\scripts\po-mask-generator"  
   cd "C:\scripts\po-mask-generator"

2. **Add the Files**  
   - `generate_po_mask_inserts.ps1` → the main script  
   - `po_patterns.json` → pattern templates (you can expand these easily)  

3. **Optional: Create a Quick Alias**  
   Add this to your PowerShell profile (`notepad $PROFILE`):

   function po {
       & "C:\scripts\po-mask-generator\generate_po_mask_inserts.ps1"
   }

   Then reload your profile:

   . $PROFILE

   ✅ Now you can simply run:  
   po

---

## 🚀 How It Works

### 1. Prompt Flow

BILLTOCD → SHIPTOCD(s) → Choose Regex Pattern → Description → Optional Defaults

### 2. Pattern Selection Menu

When run, you’ll see something like:

Select a REGEX pattern template:  
1) PO must be [X] letters followed by [Y] numbers. Example: 2 letters followed by 6 digits: AB123456  
2) PO must start with a fixed prefix then [N] digits. Example: prefix PO- then 5 digits: PO-12345  
3) PO must be exactly [N] digits. Example: 6 digits: 123456  
4) PO must be [X] letters, a dash, then [Y] digits. Example: 3 letters, dash, 4 digits: ABC-1234  
5) PO may contain letters, digits, and dashes, max [N] characters. Example: PO-ABC-123  
0) Enter custom regex

### 3. Example Run

BILLTOCD: 212751  
SHIPTOCD (single or comma-separated; blank for NULL): 100001,100002,100003  
Choose pattern number: 2  
Prefix (e.g. PO-): XY:  
Number of digits (N): 5  
Generated regex: ^XY:\d{5}$  
Use this regex? (Y/N): Y  
Suggested description: PO must start with XY: followed by 5 digits.  
Use suggested description? (Y/N): Y  
Do you want to change MATCH_REQUIRED, PRIORITY, or USEYN? (Y/N): N  

✅ **Output**

INSERT INTO HKTPWD.HT_PO_MASK (BILLTOCD, SHIPTOCD, REGEX_PATTERN, PATTERN_DESCRIPTION, MATCH_REQUIRED, PRIORITY, USEYN)  
VALUES ('212751', '100001', q'~^XY:\d{5}$~', q'~PO must start with XY: followed by 5 digits.~', 'Y', 100, 'Y');

INSERT INTO HKTPWD.HT_PO_MASK (BILLTOCD, SHIPTOCD, REGEX_PATTERN, PATTERN_DESCRIPTION, MATCH_REQUIRED, PRIORITY, USEYN)  
VALUES ('212751', '100002', q'~^XY:\d{5}$~', q'~PO must start with XY: followed by 5 digits.~', 'Y', 100, 'Y');

INSERT INTO HKTPWD.HT_PO_MASK (BILLTOCD, SHIPTOCD, REGEX_PATTERN, PATTERN_DESCRIPTION, MATCH_REQUIRED, PRIORITY, USEYN)  
VALUES ('212751', '100003', q'~^XY:\d{5}$~', q'~PO must start with XY: followed by 5 digits.~', 'Y', 100, 'Y');

---

## 🧱 Pattern File Reference (`po_patterns.json`)

Each entry defines:  
- **`label`** → menu text shown to the user  
- **`template`** → regex structure with placeholders  
- **`parameters`** → prompts for substitution values  
- **`defaultDescription`** → auto-generated text summary  
- *(optional)* **`example`** → illustrative example  

### Example Snippet

{
  "id": "letters_then_digits",
  "label": "PO must be [X] letters followed by [Y] numbers. Example: 2 letters followed by 6 digits: AB123456",
  "template": "^[A-Za-z]{__X__}\\d{__Y__}$",
  "parameters": [
    { "name": "X", "prompt": "Number of letters (X)" },
    { "name": "Y", "prompt": "Number of digits (Y)" }
  ],
  "defaultDescription": "PO must be __X__ letters followed by __Y__ numbers."
}

🧩 You can add as many templates as you want — just follow the same structure.

---

## 🧭 Workflow Overview

┌───────────────┐  
│  Start Script │  
└───────┬───────┘  
        │  
┌───────▼───────┐  
│ Prompt BILLTO │  
└───────┬───────┘  
        │  
┌───────▼────────────┐  
│ Prompt SHIPTO(s)   │  
└───────┬────────────┘  
        │  
┌───────▼──────────────┐  
│ Choose Pattern / Regex│  
└───────┬──────────────┘  
        │  
┌───────▼──────────────┐  
│ Confirm Description   │  
└───────┬──────────────┘  
        │  
┌───────▼──────────────┐  
│ Optional Defaults     │  
└───────┬──────────────┘  
        │  
┌───────▼──────────────┐  
│ Generate SQL Inserts  │  
└───────────────────────┘

---

## 🧰 Notes for Developers

- New pattern templates can be added to `po_patterns.json` without editing the PowerShell script.  
- Ensure no `~` characters appear in your regex or description (to avoid `q'~ ~'` quote conflicts).  
- Regex validation is not enforced — always test new patterns using Oracle’s `REGEXP_LIKE` before inserting into production.
