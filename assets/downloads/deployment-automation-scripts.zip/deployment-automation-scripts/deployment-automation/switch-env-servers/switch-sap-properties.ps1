# =================================================
# === SWITCH SAP.PROPERTIES FOR CUSTOMERPORTAL ===
# =================================================

param (
    [Parameter(Mandatory = $true)][string]$env,
    [Parameter(Mandatory = $true)][string]$projectPath
)

# Path to sap.properties file
$sapPropPath = "$projectPath\src\main\resources\config\sap.properties"

if (-Not (Test-Path $sapPropPath)) {
    Write-Host "[ERROR] sap.properties not found at path: $sapPropPath"
    exit 1
}

Write-Host "`n[CONFIG] Updating sap.properties for '$env' environment..."
$sapContent = Get-Content $sapPropPath -Raw

# First, comment all uncommented jco.* lines
$sapContent = [regex]::Replace($sapContent, '^(?!#)(jco\..+)', '#$1', 'Multiline')

# Choose the block to enable
$blockName = if ($env -eq "prod") { "REAL SERVER" } else { "DEV SERVER" }

# Uncomment the correct block's jco.* lines
$sapContent = [regex]::Replace(
    $sapContent,
    "(?s)(#?$blockName\s*)(.*?)(?=\n#(DEV|REAL) SERVER|\Z)",
    {
        param($m)
        $header = $m.Groups[1].Value -replace '^(?!#)', '#'
        $body = $m.Groups[2].Value -replace '(^|\n)#(jco\..+)', '$1$2'
        return "$header$body"
    },
    'Multiline'
)

Set-Content $sapPropPath $sapContent -Encoding UTF8
Write-Host "[OK] sap.properties updated for '$env'"
