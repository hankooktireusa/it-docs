# =========================================================
# === SWITCH WSDL-INFO.PROPERTIES FOR CUSTOMERPORTAL    ===
# =========================================================

param (
    [Parameter(Mandatory = $true)][string]$env,
    [Parameter(Mandatory = $true)][string]$projectPath
)

$wsdlPath = "$projectPath\src\main\resources\config\wsdl-info.properties"

if (-Not (Test-Path $wsdlPath)) {
    Write-Host "[ERROR] wsdl-info.properties not found at: $wsdlPath"
    exit 1
}

$lines = Get-Content $wsdlPath -Encoding UTF8

# Find block header indexes
$qaHeaderIndex = -1
$prdHeaderIndex = -1

for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*#\s*EAI\s+QA\b') { $qaHeaderIndex = $i }
    if ($lines[$i] -match '^\s*#\s*EAI\s+PRD\b') { $prdHeaderIndex = $i }
}

if ($qaHeaderIndex -eq -1 -or $prdHeaderIndex -eq -1) {
    Write-Host "[ERROR] Could not locate both QA and PRD blocks." -ForegroundColor Red
    exit 1
}

$qaEnd  = if ($prdHeaderIndex -gt $qaHeaderIndex) { $prdHeaderIndex - 1 } else { $lines.Count - 1 }
$prdEnd = $lines.Count - 1

function Toggle-Block {
    param (
        [string[]]$block,
        [bool]$enable
    )

    $ignoreLines = @(
        '# EAI QA', '# EAI PRD',
        '# http://202.31.7.225:57000',
        '# http://202.31.7.236:56000'
    )

    function IsIgnoredLine {
        param ($line)
        $trimmed = $line.Trim()
        return $ignoreLines -contains $trimmed -or $trimmed -match '^#?\s*http://'
    }

    function HasActiveLines {
        param ($lines)
        foreach ($line in $lines) {
            if ($line -match '^[A-Za-z0-9]+\..+=') { return $true }
        }
        return $false
    }

    if (-not $enable) {
        if (-not (HasActiveLines $block)) { return $block }
        return $block | ForEach-Object {
            if ($_ -match '^\s*$' -or (IsIgnoredLine $_)) {
                $_
            } else {
                "#$_"
            }
        }
    } else {
        $allCommented = $true
        foreach ($line in $block) {
            if (
                $line -notmatch '^\s*#' -and
                $line -match '[A-Za-z0-9]+\..+=' -and
                -not (IsIgnoredLine $line)
            ) {
                $allCommented = $false
                break
            }
        }

        return $block | ForEach-Object {
            if (IsIgnoredLine $_) {
                $_
            } elseif ($allCommented) {
                $_ -replace '^#', ''
            } else {
                if ($_ -match '^##\s*[A-Za-z0-9]+\..+=') {
                    $_ -replace '^##', '#'
                } elseif ($_ -match '^#\s*[A-Za-z0-9]+\..+=') {
                    $_ -replace '^#', ''
                } else {
                    $_
                }
            }
        }
    }
}

$preQa    = $lines[0..$qaHeaderIndex]
$qaBlock  = $lines[($qaHeaderIndex + 1)..$qaEnd]
$prdBlock = $lines[($prdHeaderIndex + 1)..$prdEnd]

if ($env -in @("dev", "local")) {
    $qaBlock  = Toggle-Block -block $qaBlock -enable $true
    $prdBlock = Toggle-Block -block $prdBlock -enable $false
} elseif ($env -eq "prod") {
    $qaBlock  = Toggle-Block -block $qaBlock -enable $false
    $prdBlock = Toggle-Block -block $prdBlock -enable $true
}

$newLines = $preQa + $qaBlock + $lines[($qaEnd + 1)..$prdHeaderIndex] + $prdBlock
Set-Content $wsdlPath $newLines -Encoding UTF8

Write-Host "[OK] wsdl-info.properties updated for '$env'" -ForegroundColor Green
