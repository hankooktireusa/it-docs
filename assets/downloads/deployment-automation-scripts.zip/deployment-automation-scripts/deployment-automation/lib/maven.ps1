# ========================================
# === MAVEN BUILD HELPER - CLEAN INSTALL ===
# ========================================

function Invoke-MavenBuild {
    param (
        [Parameter(Mandatory = $true)][string]$projectPath
    )

    Write-Host "`n[BUILD] Running Maven build (clean install)..."

    $mavenCommand = "mvn clean install"
    $buildResult = Start-Process -FilePath "cmd.exe" `
        -ArgumentList "/c", $mavenCommand `
        -WorkingDirectory $projectPath `
        -NoNewWindow -Wait -PassThru

    if ($buildResult.ExitCode -ne 0) {
        Write-Host "`n[ERROR] Maven build failed with exit code $($buildResult.ExitCode)" -ForegroundColor Red
        exit 1
    } else {
        Write-Host "`n[OK] Maven build completed successfully." -ForegroundColor Green
    }
}
