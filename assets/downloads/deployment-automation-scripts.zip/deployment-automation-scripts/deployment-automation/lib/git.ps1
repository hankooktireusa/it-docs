# ===================================
# === GIT UTILITIES - PULL LOGIC ===
# ===================================

function Invoke-GitPull {
    param (
        [Parameter(Mandatory=$true)][string]$project
    )

    $upper = $project.ToUpper()

    if (-not $projectFolders.ContainsKey($upper)) {
        Write-Host "[ERROR] Unknown project folder for '$project'"
        exit 1
    }

    $projectPath = $projectFolders[$upper]

    Write-Host "`n[GIT] Pulling latest code for $upper..."
    Set-Location $projectPath
    git pull
}
