function Invoke-RollbackDeployment {
    param (
        [string]$project,
        [string]$env,
        [string]$backupRootName
    )

    if (-not $backupRootName) {
        Write-Host "[ERROR] No backup ROOT filename found. Rollback aborted." -ForegroundColor Red
        return "rollback_failed"
    }

    Write-Host "`n[ROLLBACK] Preparing to revert deployment for '$project' in '$env'..."
    $confirm = Read-Host "Are you sure you want to rollback to '$backupRootName'? (y/n)"
    if ($confirm.ToLower() -ne 'y') {
        Write-Host "[CANCELLED] Rollback aborted by user."
        return "rollback_aborted"
    }

    # === Paths ===
    $remoteWebappsPath = "/opt/tomcat/webapps"
    $remoteWarFolder   = "$remoteWebappsPath/WAR"
    $remoteRootWar     = "$remoteWebappsPath/ROOT.war"

    # === SSH Details ===
    $key = "${project}_${env}"
    if (-not $trustedHostKeys.ContainsKey($key)) {
        Write-Host "[ERROR] No trusted SSH key found for $key" -ForegroundColor Red
        return "rollback_failed"
    }

    $hostKeyForWinSCP = $trustedHostKeys[$key].winscp
    $privateKeyPath = "C:\Users\Steven.Dunning\Documents\keys\hankooktire-us-key.ppk"
    $openCommand = "open sftp://ec2-user@localhost/ -hostkey=`"$hostKeyForWinSCP`" -privatekey=`"$privateKeyPath`" -rawsettings AuthGSSAPIKEX=1"

    # === WinSCP Rollback Script ===
    $rollbackScript = @"
option batch abort
option confirm off
$openCommand

# Step 1: Delete the failed/new ROOT.war
rm $remoteRootWar

# Step 2: List backup folder contents and confirm the file is present
ls $remoteWarFolder
stat $remoteWarFolder/$backupRootName

# Step 3: Move backup ROOTYYMMDD.war back to webapps as ROOT.war
mv $remoteWarFolder/$backupRootName $remoteRootWar

exit
"@

    $tempRollback = "$env:TEMP\winscp_rollback.txt"
    $rollbackScript | Out-File -Encoding ASCII -FilePath $tempRollback

    Write-Host "[INFO] Rolling back deployment, restoring $backupRootName..." -ForegroundColor Yellow
    & "winscp.com" "/script=$tempRollback"

    Write-Host "[ROLLBACK COMPLETE] $backupRootName restored as ROOT.war." -ForegroundColor Green
    return "rollback_done"
}
