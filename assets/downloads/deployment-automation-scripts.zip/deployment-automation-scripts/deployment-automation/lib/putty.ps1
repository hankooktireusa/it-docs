function Set-TrustedHostKey {
    param (
        [string]$project,
        [string]$env
    )

    $key = "${project}_${env}"

    if ($trustedHostKeys.ContainsKey($key)) {
        $entry = $trustedHostKeys[$key]
        $regPath = "HKCU:\\Software\\SimonTatham\\PuTTY\\SshHostKeys"

        if (-not (Test-Path $regPath)) {
            New-Item -Path $regPath -Force | Out-Null
        }

        Set-ItemProperty -Path $regPath -Name $entry.keyName -Value $entry.keyValue
        Write-Host "[INFO] Updated PuTTY cache with trusted key for session '$key'" -ForegroundColor Cyan
    } else {
        Write-Host "[WARN] No trusted host key found for session '$key'" -ForegroundColor Yellow
    }
}

function Is-PuttySessionOpen {
    param (
        [string]$sessionName
    )

    $puttyWindows = Get-Process putty -ErrorAction SilentlyContinue | Where-Object {
        $_.MainWindowTitle -like "*$sessionName*"
    }

    return $puttyWindows.Count -gt 0
}

function Start-PuttySession {
    param (
        [string]$sessionName,
        [switch]$force
    )

    if (-not $force -and (Is-PuttySessionOpen -sessionName $sessionName)) {
        Write-Host "[INFO] PuTTY session '$sessionName' is already running." -ForegroundColor Gray
    } else {
        if ($force -and (Is-PuttySessionOpen -sessionName $sessionName)) {
            Write-Host "[INFO] Closing existing session: $sessionName"
            Get-Process putty -ErrorAction SilentlyContinue | Where-Object {
                $_.MainWindowTitle -eq $sessionName
            } | ForEach-Object { $_.Kill() }

            Start-Sleep -Milliseconds 500
        }

        Write-Host "[INFO] Starting PuTTY session: $sessionName"
        Start-Process -FilePath "putty.exe" -ArgumentList "-load", "`"$sessionName`""
    }
}

function Wait-ForPuttyWindow {
    param (
        [string]$sessionName,
        [int]$timeoutSeconds = 10
    )

    $endTime = (Get-Date).AddSeconds($timeoutSeconds)

    while ((Get-Date) -lt $endTime) {
        $puttyWindow = Get-Process -Name "putty" -ErrorAction SilentlyContinue | Where-Object {
            $_.MainWindowTitle -eq $sessionName
        }

        if ($puttyWindow) {
            Write-Host "[OK] PuTTY session '$sessionName' is active." -ForegroundColor Green
            return
        }

        Start-Sleep -Milliseconds 500
    }

    Write-Host "[WARN] Timed out waiting for PuTTY session '$sessionName' to appear." -ForegroundColor Yellow
}

function Close-AllPuttySessions {
    $openSessions = Get-Process putty -ErrorAction SilentlyContinue

    if ($openSessions) {
        Write-Host "`n[WARN] Detected open PuTTY sessions. These may cause deployment errors." -ForegroundColor Yellow
        Write-Host "       The following sessions are currently open:" -ForegroundColor Yellow

        foreach ($session in $openSessions) {
            Write-Host "       - $($session.MainWindowTitle)"
        }

        Write-Host "`n[INFO] These will be closed before deployment continues." -ForegroundColor Cyan
        Write-Host "       If you're using them for something else, please save your work now."
        Read-Host "`n[CONTINUE] Press Enter to close PuTTY sessions and proceed"

        $openSessions | ForEach-Object {
            Write-Host " - Closing: $($_.MainWindowTitle)"
            $_.Kill()
            Start-Sleep -Milliseconds 200
        }
    }
}

function Launch-PuttySessionsForDeployment {
    param (
        [string]$project,
        [string]$env
    )

    Close-AllPuttySessions

    $key = switch ($env) {
        "dev"   { "${project}_dev" }
        "prod1" { "${project}_prod1" }
        "prod2" { "${project}_prod2" }
        "local" { "${project}_dev" }
        default { "" }
    }

    if ($puttySessions.ContainsKey($key)) {
        $targetSession = $puttySessions[$key]
        Start-PuttySession -sessionName $targetSession
        Wait-ForPuttyWindow -sessionName $targetSession -timeoutSeconds 10
    } else {
        Write-Host "[WARN] No PuTTY session mapped for project '$project' in environment '$env'" -ForegroundColor Yellow
    }

    if ($puttySessions.ContainsKey("common_local")) {
        Set-TrustedHostKey -project $project -env $env
        $localSession = $puttySessions["common_local"]
        Start-PuttySession -sessionName $localSession
        Wait-ForPuttyWindow -sessionName $localSession -timeoutSeconds 10
    } else {
        Write-Host "[WARN] Missing 'common_local' PuTTY session in config." -ForegroundColor Yellow
    }

    Write-Host "`n[INFO] PuTTY sessions launched. Click back on this window or press Alt+Tab to continue..." -ForegroundColor Yellow
}
