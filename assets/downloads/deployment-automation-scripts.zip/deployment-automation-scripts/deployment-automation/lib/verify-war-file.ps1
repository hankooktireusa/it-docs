# ===========================================
# === VERIFY WAR FILE FOR SELECTED BUILD ===
# ===========================================

function Verify-WarFile {
    param (
        [string]$project,
        [string]$projectPath
    )

    $projectKey = $project.ToUpper()
    $warPath = $warPaths[$project.ToUpper()]

    Write-Host "`n[VERIFY] Checking for WAR file at:"
    Write-Host "         $warPath"

    if (Test-Path $warPath) {
        Write-Host "[OK] WAR file exists: $warPath" -ForegroundColor Green
        return $true
    } else {
        Write-Host "[ERROR] WAR file not found at expected location: $warPath" -ForegroundColor Red
        return $false
    }
}

