# ⚙️ Deployment Automation for CustomerPortal (CP) and WebOrder (WO)

This project automates the deployment process of **CustomerPortal (CP)** and **WebOrder (WO)** applications to DEV and PROD environments.

## ✨ Features at a Glance

- 🔄 Environment-aware config switching (datasource, SAP, WSDL)
- ⚙️ Automated Git pull and optional Maven builds
- 📦 Safe WAR/ROOT backup, transfer, and deployment via WinSCP
- 🔐 Dynamic SSH host key trust for PuTTY sessions
- 🖥️ PuTTY automation for Tomcat restart and live log monitoring
- 🔁 Seamless PROD1 → PROD2 continuation using same WAR (no rebuild)
- ⏪ Post-deployment validation prompts and rollback support

---

---

## 📁 Project Structure

```yaml
deployment-automation/
├── config.ps1                           # Shared paths, session names, and SSH host keys
├── main.ps1                             # Main entry point to automate full deployment
├── README.md                            # Project documentation
│
├── lib/
│   ├── git.ps1                          # Git operations (fetch, pull, commit)
│   ├── maven.ps1                        # Maven build process functions
│   ├── post-check-prompts.ps1           # Post-deployment validation prompts
│   ├── post-check-and-rollback.ps1      # Shared rollback + post-check orchestration
│   ├── putty-automation.ps1             # Automated PuTTY commands
│   ├── putty.ps1                        # Launch PuTTY sessions and manage SSH host keys
│   ├── rollback-deployment.ps1          # Rollback routine to restore previous WAR file
│   ├── verify-war-file.ps1              # Validates WAR file integrity before deploy
│   ├── winscp-deploy.ps1                # Transfers WAR/ROOT safely using WinSCP scripting
│   └── deploy-to-second-prod.ps1        # Handles second PROD deployment using existing WAR
│
└── switch-env-servers/
    ├── switch-datasource-server.ps1     # Toggles datasource-context.xml for target env
    ├── switch-sap-properties.ps1        # Switches SAP server config (DEV/PROD)
    └── switch-wsdl-info.ps1             # Switches WSDL config comments for env
```

---

## 🔧 Initial Setup (One-Time)

1. ✅ **Install Prerequisites**
   - [Git](https://git-scm.com/)
   - [Apache Maven](https://maven.apache.org/)
   - [PuTTY](https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html)
   - [WinSCP](https://winscp.net/eng/download.php)
   
2. ✅ **Add `WinSCP.com` to PATH**  
   🛠️ WinSCP Setup  
   <details>
   <summary>Expand for full WinSCP setup instructions</summary>

   <br>

   **Step 1: Locate WinSCP**  
   Run the following PowerShell command to find where WinSCP is installed:

   ```powershell
   Get-ChildItem -Path "C:\Program Files*", "C:\Program Files (x86)*" -Recurse -Filter WinSCP.com -ErrorAction SilentlyContinue
   ```

   Note the full path of the file (e.g., `C:\Program Files (x86)\WinSCP\WinSCP.com`). You’ll use the folder path in the next step.

   **Step 2: Add WinSCP to PATH**  
   Run the following PowerShell snippet to add WinSCP to your user-level PATH environment variable:

   ```powershell
   $winscpPath = "C:\Program Files (x86)\WinSCP"  # Update if your path is different
   $existingPath = [System.Environment]::GetEnvironmentVariable("Path", "User")

   if (-not $existingPath.Split(';') -contains $winscpPath) {
       [System.Environment]::SetEnvironmentVariable("Path", "$existingPath;$winscpPath", "User")
       Write-Host "✅ WinSCP path added to user PATH. Restart PowerShell to apply changes." -ForegroundColor Green
   } else {
       Write-Host "ℹ️ WinSCP path is already in PATH." -ForegroundColor Yellow
   }
   ```

   After running the script, restart your terminal or PowerShell window.

   **Step 3: Verify Setup**  
   After restarting, run this command to verify WinSCP is accessible from the command line:

   ```powershell
   Get-Command winscp.com
   ```

   You should see output showing `WinSCP.com` as an application with its path.

   </details>

3. ✅ **Configure `config.ps1`**
   - Set Git root directory
   - Define WAR paths, PuTTY session names, and SSH host key mappings

4. ✅ **Trusted Host Keys**  
   - SSH host key fingerprints for each PuTTY and WinSCP session are stored in `config.ps1`  
   - These keys are used to pre-trust PuTTY connections **and** pass the expected `-hostkey` to WinSCP   
    <details>
    <summary>🔐 Expand for full SSH key setup instructions (PuTTY + WinSCP)</summary>

    <br>

    #### 🔁 Step 1: Open Target + Local PuTTY Sessions Together

    For each remote PuTTY session below:

    - Open the target PuTTY session (e.g., `Web Order - DEV`)  
    - Then open the `Amazon Server - local` session  
    *(This is required to trigger proper key caching over port-forwarded localhost)*  
    - If prompted with a **host key warning**, click **Accept**  
    - Once both are connected and key saved, **close them**

    #### 🔍 Step 2: Retrieve PuTTY Host Key from Registry

    Run the following in PowerShell:

    ```powershell
    Get-ItemProperty -Path "HKCU:\Software\SimonTatham\PuTTY\SshHostKeys" | Select-Object -ExpandProperty 'ssh-ed25519@22:localhost'
    ```

    Copy the full value. It should look like:

    ```text
    0xABCDEF1234...,0x1234FEDCBA...
    ```

    #### 📤 Step 3: Retrieve Key for WinSCP

    In the same PowerShell window:

    ```powershell
    winscp.com
    ```
    Then enter the following, using the correct path to your SSH ppk file (right click to paste in terminal after you copy the following line):

    ```powershell
    open sftp://ec2-user@localhost/ -privatekey="C:\PATH\TO\YOUR\hankooktire-us-key.ppk"
    ```

    This will output something like:

    ```
    The ssh-ed25519 key fingerprint is:
    ssh-ed25519 255 h4B1QT...
    ```

    Copy the entire fingerprint string starting with ssh-ed25519 255 ....
    This full value will be used for the winSCPKey field in config.ps1.   

    To exit the winscp session, simply hit 'Esc' and then type:

    ```powershell
    exit
    ```

    #### 🛠 Step 4: Add Both Values to config.ps1

    Open `config.ps1` and update as follows:

    ```powershell
    $trustedPuttyHostKeys = @{
        "cp_dev" = @{
            keyName     = "ssh-ed25519@22:localhost"
            keyValue    = "0xABCDEF...,0x123456..."     # For PuTTY (registry)
            winSCPKey   = "ssh-ed25519 255 ...."     # For WinSCP (-hostkey)
        }
        # Add more entries for other environments
    }
    ```

    Make sure your session labels (`cp_dev`, `wo_prod1`, etc.) match the values used in your deployment script.

    #### ✅ Step 5: Validate in Script

    Once configured:

    - The deployment script will:
    - Trust PuTTY sessions by injecting the `keyValue` into the registry  
    - Use `winSCPKey` for `-hostkey` during file transfers

    You should no longer see any SSH key mismatch warnings.

    ---

    #### 📋 Repeat for These Sessions:

    - Web Order - DEV  
    - Web Order - PRD1  
    - Web Order - PRD2  
    - Customer Portal - DEV  
    - Customer Portal - PRD1  
    - Customer Portal - PRD2  

    💡 `Amazon Server - local` must be opened **immediately after** each remote session to ensure proper key caching under `localhost`.

    </details>

5. ✅ **Set PuTTY Session Window titles = Session Names**  
   For the automation scripts to correctly focus and send commands to PuTTY sessions, the PuTTY window titles must exactly match the session names listed in your `config.ps1` file (e.g., `"Customer Portal - DEV"`, `"Amazon Server - local"`).

   **Steps to Configure PuTTY Window Titles**  
   <details>
   <summary>Expand for full step-by-step instructions</summary>

   <br>

   1. **Open PuTTY Configuration**  
      - Launch PuTTY.  
      - Select a saved session (e.g., `Customer Portal - DEV`) from the session list.  
      - Click **Load**.

   2. **Set a Fixed Window Title**  
      - In the left panel, navigate to:  
        `Window → Behaviour`  
      - Under *Window title*, check:  
        ✅ **Window title string**  
      - In the **Window title string** box, enter the exact session name as defined in your config, for example:  
        `Customer Portal - DEV`  
      ⚠️ *This is case-sensitive and must match EXACTLY.* (You can copy/paste from the **Saved Sessions** textbox.)

   3. **Prevent Title Changes by the Remote Host**  
      - In the left panel, navigate to:  
        `Terminal → Features`  
      - Check the option:  
        ✅ **Disable remote-controlled window title changing**  
      - This ensures the window title stays fixed even if the server tries to change it.

   4. **Save the Updated Session**  
      - Go back to the **Session** category.  
      - Click **Save** to update the session with these settings.

   5. **Repeat for All Sessions**  
      Update all PuTTY saved sessions used in the automation:  
      - `Customer Portal - DEV`  
      - `Customer Portal - PRD1`  
      - `Customer Portal - PRD2`  
      - `Web Order - DEV`  
      - `Web Order - PRD1`  
      - `Web Order - PRD2`  
      - `Amazon Server - local`

   6. **Test the Titles**  
      - Open each PuTTY session and verify:  
        - The window title in the header and taskbar exactly matches the session name in `config.ps1`.  
        - The title does **not change** after connecting.

   </details>


---

## 🚀 How to Run a Deployment

From PowerShell:

```powershell
cd C:\scripts\deployment-automation
.\main.ps1
```

🛠️ Create a PowerShell Alias (Optional)  
<details>
<summary>Expand for steps to create a PowerShell alias</summary>

<br>

You can create an alias to quickly run the deployment script from any PowerShell session:

**1. Open PowerShell as Administrator**  
- Right-click PowerShell and select **"Run as administrator"** (needed if you are updating your profile)

**2. Open your PowerShell profile script**  
This script runs every time PowerShell starts:

```powershell
notepad $PROFILE
```

- If prompted to create the file, click **Yes**

**3. Add your alias to the bottom of the file**  
Replace the path below with the full path to your main deployment script:

```powershell
Set-Alias myAlias "C:\scripts\deployment-automation\main.ps1"
```

- You can change `myAlias` to any shortcut name you'd like (e.g., `rundeploy`, `deployproject`, `dprj`, etc.)

**4. Save and close Notepad**  
- Restart PowerShell to load the new alias

**5. Run the alias**  
Now you can just type this to launch the deployment script:

```powershell
myAlias
```

</details>

---

### You will be guided through:

- ✅ Project selection (**CustomerPortal** or **WebOrder**)  
- ✅ Environment selection (**LOCAL**, **DEV**, **PROD1**, or **PROD2**)  
- ✅ Git pull (skipped on PROD2 continuation)  
- ✅ Config switch (if targeting DEV or first-time PROD)  
- ✅ Maven build (unless using existing WAR for PROD2)  
- ✅ WAR validation (verify WAR file integrity)  
- ✅ PuTTY session launch (**target + local**)  
- ✅ Safe WAR file transfer and rename using **WinSCP**  
- ✅ Rename existing `ROOT` → backup (`ROOTYYMMDD.war`)  
- ✅ Deploy new WAR as `ROOT.war`  
- ✅ Restart Tomcat via PuTTY  
- ✅ Live log monitoring via PuTTY  
- ✅ Browser-based verification (manual step)  
- ✅ Optional WAR rollback prompt  
- ✅ Prompt to deploy to **PROD2** (if coming from PROD1)  
- ✅ Revert config files back to LOCAL at the end

🧪 Safe WAR Deployment Logic
    The script performs:
        Copy ROOT to ROOTTEST.war (local backup)
        Move ROOT to WAR folder with timestamp (ROOTYYMMDD.war)
        Upload new WAR snapshot from local machine
        Rename it to ROOT.war and move into /opt/tomcat/webapps/
        Prompt you to verify in browser before continuing
        You can undo this at the end to fully restore the original ROOT safely.

🔐 Host Key Auto-Trust
    When PuTTY sessions switch across environments, SSH key mismatch prompts may appear.
        To prevent that:
            This project sets the trusted PuTTY SSH host keys dynamically
            Defined per session in config.ps1 > $trustedHostKeys
            Example:
                $trustedHostKeys = @{
                    "wo_dev" = @{
                        "keyName"  = "ssh-ed25519@22:localhost"
                        "keyValue" = "<host key hash>"
                    }
                }

🛠 Post-Deployment Steps
    Depending on project/environment:
        Switch config blocks back to local when finished
        Check browser + SAP connection
        Perform rollback only if deployment fails
    For first-time PROD deploys, WAR must be rebuilt using PROD config

👥 For New Developers
    Clone this repo to:
        C:\scripts\deployment-automation
    Open PowerShell (Run as Administrator the first time)
        Run:
            .\main.ps1
        Walk through the prompts and follow instructions
    Ask a team member to guide you the first time!

🧼 Cleanup
    Logs are viewable in catalina.out after restart
    Backups remain in WAR folder (named with ROOTYYMMDD.war)
    You may remove them after confirmation of successful deployment
    
🔚 After deployment completes (including PROD2 if applicable), the script will:
    Revert config files to LOCAL versions
    Automatically close any opened PuTTY sessions

## 🧭 Deployment Flow Overview

```text
          ┌───────────────┐
          │  Select App   │  ← (CP or WO)
          └───────┬───────┘
                  │
           ┌──────▼──────┐
           │ Select Env  │  ← (LOCAL, DEV, PROD1, PROD2)
           └──────┬──────┘
                  │
      ┌───────────▼────────────┐
      │      Git Pull          │  ← Skipped on PROD2 continuation
      └───────────┬────────────┘
                  │
         ┌────────▼────────┐
         │  Config Switch  │  ← Only on DEV or first-time PROD
         └────────┬────────┘
                  │
        ┌─────────▼─────────┐
        │ Run Maven Build   │
        └─────────┬─────────┘
                  │
        ┌─────────▼──────────┐
        │ Validate WAR File  │
        └─────────┬──────────┘
                  │
     ┌────────────▼─────────────┐
     │  Start PuTTY Sessions    │
     └────────────┬─────────────┘
                  │
   ┌──────────────▼──────────────┐
   │ Transfer WAR using WinSCP   │
   └──────────────┬──────────────┘
                  │
  ┌───────────────▼────────────────┐
  │ Rename existing WAR → backup   │
  │ Deploy new WAR as ROOT.war     │
  └───────────────┬────────────────┘
                  │
     ┌────────────▼─────────────┐
     │ Restart Tomcat via PuTTY │
     └────────────┬─────────────┘
                  │
     ┌────────────▼────────────┐
     │ Check Logs + Rollback?  │
     └────────────┬────────────┘
                  │
         ┌────────▼────────┐
         │ Deploy to PROD2?│  ← If PROD1 completed
         └────────┬────────┘
                  │ Yes
                  ▼
      (Resume from: PuTTY session → WAR upload → restart)
                  │
     ┌────────────▼──────────────┐
     │ Revert Configs to LOCAL   │
     │ Close open PuTTY sessions │  ← Final cleanup step
     └───────────────────────────┘

```

Happy Deploying! 🚀