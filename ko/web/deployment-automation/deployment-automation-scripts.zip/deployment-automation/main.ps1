# ===================================
# === MAIN SCRIPT - DEPLOY LAUNCH ===
# ===================================

$host.UI.RawUI.WindowTitle = "Deployment Automation"
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

# ==================
# === LOAD FILES ===
# ==================

. "$scriptRoot\config.ps1"
. "$scriptRoot\lib\putty.ps1"
. "$scriptRoot\lib\git.ps1"
. "$scriptRoot\switch-env-servers\switch-datasource-server.ps1"
. "$scriptRoot\lib\maven.ps1"
. "$scriptRoot\lib\verify-war-file.ps1"
. "$scriptRoot\lib\winscp-deploy.ps1"
. "$scriptRoot\lib\putty-automation.ps1"
. "$scriptRoot\lib\post-check-prompts.ps1"
. "$scriptRoot\lib\rollback-deployment.ps1"
. "$scriptRoot\lib\post-check-and-rollback.ps1"
. "$scriptRoot\lib\deploy-to-second-prod.ps1"

# ================================
# === ENVIRONMENT SELECTION    ===
# ================================

$envOptions = @("local", "dev", "prod1", "prod2")
$env = $null

do {
    Write-Host "`n[ENV] Select environment to deploy to:"
    for ($i = 0; $i -lt $envOptions.Count; $i++) {
        Write-Host "[$($i + 1)] $($envOptions[$i].ToUpper())"
    }
    Write-Host "[c] Cancel"

    $envChoice = Read-Host "Enter the number of the environment to use"

    if ($envChoice.ToLower() -eq 'c') {
        Write-Host "[CANCEL] Cancelled."
        exit
    }

    if ($envChoice -match '^\d+$') {
        $index = [int]$envChoice - 1
        if ($index -ge 0 -and $index -lt $envOptions.Count) {
            $env = $envOptions[$index]
            Write-Host "[OK] Selected environment: $env"
        } else {
            Write-Host "[ERROR] Invalid environment number. Try again."
        }
    } else {
        Write-Host "[ERROR] Invalid input. Enter a number or 'c' to cancel."
    }
} while (-not $env)

# === Set nextProd if we’re in a PROD env ===
if ($env -eq "prod1") {
    $nextProd = "prod2"
} elseif ($env -eq "prod2") {
    $nextProd = "prod1"
}

# ================================
# === PROJECT SELECTION        ===
# ================================

$projectOptions = @("wo", "cp")
$project = $null

do {
    Write-Host "`n[PROJECT] Select project to deploy:"
    Write-Host "[1] WebOrder (wo)"
    Write-Host "[2] CustomerPortal (cp)"
    Write-Host "[c] Cancel"

    $projectChoice = Read-Host "Enter the number of the project to deploy"

    if ($projectChoice.ToLower() -eq 'c') {
        Write-Host "[CANCEL] Cancelled."
        exit
    }

    if ($projectChoice -match '^\d+$') {
        $index = [int]$projectChoice - 1
        if ($index -ge 0 -and $index -lt $projectOptions.Count) {
            $project = $projectOptions[$index]
            Write-Host "[OK] Selected project: $project"
        } else {
            Write-Host "[ERROR] Invalid project number. Try again."
        }
    } else {
        Write-Host "[ERROR] Invalid input. Enter a number or 'c' to cancel."
    }
} while (-not $project)

# ======================================
# === DEPLOYMENT CONTINUES FROM HERE ===
# ======================================

Write-Host "`n[INFO] Starting deployment for project '$project' to environment '$env'..."

$projectPath = $projectFolders[$project.ToUpper()]
$warPath = $warPaths[$project.ToUpper()]

# === GIT ===
$doGit = Read-Host "`n[GIT] Pull latest code for project '$project'? (y/n)"
if ($doGit.ToLower() -eq 'y') {
    Invoke-GitPull -project $project
    Write-Host "[INFO] Git pull complete. Proceeding with config switch..."
} else {
    Write-Host "[SKIP] Git pull skipped. Proceeding with config switch..."
}

# === CONFIG SWITCH ===
Set-Datasource-ForEnvironment -project $project -env $env -projectPath $projectPath
if ($project -eq 'cp') {
    & "$scriptRoot\switch-env-servers\switch-sap-properties.ps1" -env $env -projectPath $projectPath
    & "$scriptRoot\switch-env-servers\switch-wsdl-info.ps1" -env $env -projectPath $projectPath
}

# === BUILD ===
$buildPrompt = Read-Host "`n[BUILD] Run Maven build for '$project' in '$env' environment? (y/n)"
if ($buildPrompt.ToLower() -eq 'y') {
    Invoke-MavenBuild -projectPath $projectPath
} else {
    Write-Host "[INFO] Skipping Maven build for $project in $env."
}

# === VERIFY WAR ===
Verify-WarFile -project $project -projectPath $projectPath

# === LAUNCH PUTTY ===
Launch-PuttySessionsForDeployment -project $project -env $env

# === FILE TRANSFER ===
$backupFilename = Run-WinSCPDeployment -project $project -env $env -warPath $warPath
if (-not $backupFilename) {
    Write-Host "[WARN] No backup filename returned. Rollback may not work." -ForegroundColor Yellow
}

# === TOMCAT + LOGS ===
$ranPuttyCommands = $false
$puttyPrompt = Read-Host "`n[PUTTY] Run Tomcat restart and log commands in PuTTY for '$project' in '$env'? (y/n)"
if ($puttyPrompt.ToLower() -eq 'y') {
    Send-TomcatRestartAndLogs -sessionName "Amazon Server - local"
    $ranPuttyCommands = $true
} else {
    Write-Host "[INFO] Skipping PuTTY Tomcat and log commands."
}

# === POST CHECKS + ROLLBACK ===
Run-PostChecksAndRollback -project $project -env $env -backupFilename $backupFilename -ranPuttyCommands $ranPuttyCommands

# === OPTIONAL CONTINUATION TO SECOND PROD ===
if ($env -like "prod*" -and $nextProd) {
    $continue = Read-Host "`n[CONFIRM] Is $env verified working? Continue to deploy to $nextProd? (y/n)"
    if ($continue -eq 'y') {
        $env = $nextProd
        Deploy-ToSecondProd -project $project -env $env -warPath $warPath -projectPath $projectPath
    } else {
        Write-Host "[SKIP] Skipping $nextProd deployment." -ForegroundColor Yellow
    }
}

# === FINAL STEP: RESET TO LOCAL ===
Reset-Datasource-ToLocal -project $project -projectPath $projectPath
Write-Host "`n[COMPLETE] Deployment finished for '$project' in '$env' environment."
Write-Host "[RESET] Local database settings have been reapplied to prevent accidental remote usage." -ForegroundColor Yellow

Close-PuttySessions $project $env
Write-Host "[CLEANUP] Closed PuTTY sessions for $project in $env." -ForegroundColor Green

