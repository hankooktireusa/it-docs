# =====================================
# === CONFIGURATION - SHARED VALUES ===
# =====================================

# Root Git directory for all users (override this per user)
$gitRoot = ""

# Git working folders per project
$projectFolders = @{
    "CP" = "$gitRoot\CustomerPortal"
    "WO" = "$gitRoot\WebOrder"
}

# WAR file paths per project
$warPaths = @{
    "CP" = "$($projectFolders["CP"])\target\hankooktire-0.0.1-SNAPSHOT.war"
    "WO" = "$($projectFolders["WO"])\target\hankooktire-1.1.0-BUILD-SNAPSHOT.war"
}

# PuTTY session names per project/environment combo
$puttySessions = @{
    "cp_dev"       = ""
    "cp_prod1"     = ""
    "cp_prod2"     = ""
    "wo_dev"       = ""
    "wo_prod1"     = ""
    "wo_prod2"     = ""
    "common_local" = ""
}

# ======================================
# === TRUSTED SSH HOST KEYS FOR PUTTY ==
# ======================================

$trustedHostKeys = @{
    "cp_dev" = @{
        keyName  = ""
        keyValue = ""
        winscp   = ""
    }
    "cp_prod1" = @{
        keyName  = ""
        keyValue = ""
        winscp   = ""
    }
    "cp_prod2" = @{
        keyName  = ""
        keyValue = ""
        winscp   = ""
    }
    "wo_dev" = @{
        keyName  = ""
        keyValue = ""
        winscp   = ""
    }
    "wo_prod1" = @{
        keyName  = ""
        keyValue = ""
        winscp   = ""
    }
    "wo_prod2" = @{
        keyName  = ""
        keyValue = ""
        winscp   = ""
    }
}
