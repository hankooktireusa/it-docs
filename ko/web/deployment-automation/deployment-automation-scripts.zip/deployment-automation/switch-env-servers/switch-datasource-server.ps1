# ==================================================================
# === DATASOURCE SWITCHING LOGIC - MODULAR PER PROJECT + ENV    ===
# ==================================================================

function Set-Datasource-ForEnvironment {
    param (
        [Parameter(Mandatory=$true)][string]$project,
        [Parameter(Mandatory=$true)][string]$env,
        [Parameter(Mandatory=$true)][string]$projectPath
    )

    if ($project -eq 'cp') {
        $xmlPath = "$projectPath\src\main\resources\config\spring\datasource-context.xml"

        if (-not (Test-Path $xmlPath)) {
            Write-Host "[ERROR] Config file not found at $xmlPath"
            exit 1
        }

        Write-Host "`n[CONFIG] Updating CP datasource-context.xml for '$env'..."
        $xmlContent = Get-Content $xmlPath -Raw

        $markers = @{ "local" = "LOCAL"; "dev" = "DEV AWS"; "prod" = "PROD AWS" }
        $marker = $markers[$env]

        # Comment all blocks
        $xmlContent = [regex]::Replace($xmlContent,
          '(?s)(<!--\s*(LOCAL|DEV AWS|PROD AWS)\s*-->\s*)<bean id="dataSource"(.*?)</bean>',
          { param($m) $m.Groups[1].Value + '<!-- <bean id="dataSource"' + $m.Groups[3].Value + '</bean> -->' })

        # Uncomment selected block
        $pattern = "(?s)(<!--\s*$marker\s*-->\s*)<!--\s*<bean id=""dataSource""(.*?)</bean>\s*-->"
        $xmlContent = [regex]::Replace($xmlContent, $pattern, '$1<bean id="dataSource"$2</bean>')

        Set-Content $xmlPath $xmlContent -Encoding UTF8
        Write-Host "[OK] Updated CP datasource-context.xml for '$env'"
    }

    elseif ($project -eq 'wo') {
        $envFolder = if ($env -eq "prod") { "PROD" } else { "DEV" }
        $xmlPath = "$projectPath\src\main\resources\config\$envFolder\spring\datasource-context.xml"

        if (-not (Test-Path $xmlPath)) {
            Write-Host "[ERROR] Config file not found at $xmlPath"
            exit 1
        }

        Write-Host "`n[CONFIG] Updating WO $envFolder datasource-context.xml..."
        $xmlContent = Get-Content $xmlPath -Raw

        # Comment all current URLs
        $xmlContent = [regex]::Replace(
            $xmlContent,
            '^[ \t]*(?<!<!--)[ \t]*<property name="url" value="jdbc:oracle:thin:@.*?" />',
            { param($m) "    <!-- " + $m.Value.Trim() + " -->" },
            'Multiline'
        )

        # Uncomment the right line
        if ($env -eq 'local') {
            $xmlContent = [regex]::Replace(
                $xmlContent,
                '<!--\s*<property name="url" value="jdbc:oracle:thin:@localhost:1521:ORCL" />\s*-->',
                '    <property name="url" value="jdbc:oracle:thin:@localhost:1521:ORCL" />',
                'Multiline'
            )
        }
        elseif ($env -eq 'dev') {
            $xmlContent = [regex]::Replace(
                $xmlContent,
                '<!--\s*<property name="url" value="jdbc:oracle:thin:@hankooktire-us-dev-db\..+?" />\s*-->',
                '    <property name="url" value="jdbc:oracle:thin:@hankooktire-us-dev-db.cchxlw7s8qgg.us-east-2.rds.amazonaws.com:1521:ORCL" />',
                'Multiline'
            )
        }
        elseif ($env -eq 'prod') {
            $xmlContent = [regex]::Replace(
                $xmlContent,
                '<!--\s*<property name="url" value="jdbc:oracle:thin:@hankooktire-us-prd-db\..+?" />\s*-->',
                '    <property name="url" value="jdbc:oracle:thin:@hankooktire-us-prd-db.cchxlw7s8qgg.us-east-2.rds.amazonaws.com:1521:ORCL" />',
                'Multiline'
            )
        }

        Set-Content $xmlPath $xmlContent -Encoding UTF8
        Write-Host "[OK] Updated WO $envFolder datasource-context.xml for '$env'"
    }
}

function Reset-Datasource-ToLocal {
    param (
        [Parameter(Mandatory=$true)][string]$project,
        [Parameter(Mandatory=$true)][string]$projectPath
    )

    if ($project -eq 'cp') {
        # One file only
        Set-Datasource-ForEnvironment -project 'cp' -env 'local' -projectPath $projectPath
    }

    elseif ($project -eq 'wo') {
        # Both DEV and PROD files
        Set-Datasource-ForEnvironment -project 'wo' -env 'local' -projectPath $projectPath
        Set-Datasource-ForEnvironment -project 'wo' -env 'local' -projectPath $projectPath
    }
}
