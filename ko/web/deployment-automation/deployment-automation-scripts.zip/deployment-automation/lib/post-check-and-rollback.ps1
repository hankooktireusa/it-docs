function Run-PostChecksAndRollback {
    param (
        [string]$project,
        [string]$env,
        [string]$backupFilename,
        [bool]$ranPuttyCommands
    )

    $rollbackAction = ""
    do {
        $rollbackAction = Invoke-PostCheckPrompts -project $project -env $env

        if ($rollbackAction -eq "rollback") {
            Write-Host "`n[INFO] Rolling back deployment..." -ForegroundColor Yellow

            if ($backupFilename) {
                $result = Invoke-RollbackDeployment -project $project -env $env -backupRootName $backupFilename

                if ($result -eq "rollback_done") {
                    Write-Host "[INFO] Rollback successful. Restarting Tomcat and re-running checks..." -ForegroundColor Cyan

                    if ($ranPuttyCommands) {
                        Send-TomcatRestartAndLogs -sessionTitle "Amazon Server - local"
                    }

                    $rollbackAction = Invoke-PostCheckPrompts -project $project -env $env
                } else {
                    Write-Host "[ERROR] Rollback failed or aborted." -ForegroundColor Red
                    return
                }
            } else {
                Write-Host "[ERROR] No backup file recorded, cannot rollback automatically." -ForegroundColor Red
                return
            }
        }
    } while ($rollbackAction -eq "rollback")
}
