function Invoke-PostCheckPrompts {
    param (
        [string]$project,
        [string]$env
    )

    Write-Host "`n[MANUAL CHECKS] Please verify the deployment manually for project '$project' in environment '$env'." -ForegroundColor Cyan
    Write-Host "-----------------------------------------------------------"

    Write-Host "[1] Check Tomcat logs in the PuTTY session for errors or successful deployment messages."
    Write-Host "[2] Confirm that SAP connection works as expected."

    if ($project -eq "cp") {
        Write-Host "     - In browser, go to: OE PSI -> inbound, click search box."
    }
    elseif ($project -eq "wo") {
        Write-Host "     - In browser, click 'National Accounts Directory', search Bill-To No: 212751."
    }

    if ($env -eq "dev" -or $env -eq "local") {
        Write-Host "     - Expected DEST in logs: HKQ"
    }
    else {
        Write-Host "     - Expected DEST in logs: HKP"
    }

    Write-Host "-----------------------------------------------------------"
    Write-Host "Select the next action:"
    Write-Host "[1] Continue Deployment"
    Write-Host "[2] Rollback changes and restore previous ROOT.war"
    Write-Host "[c] Cancel process"

    $choice = Read-Host "Enter your choice (1/2/c)"


    switch ($choice.ToLower()) {
        "1" { 
            Write-Host "[INFO] Continuing deployment process..." -ForegroundColor Green
            return "continue"
        }
        "2" {
            Write-Host "[INFO] Rollback selected. The previous ROOT.war will be restored." -ForegroundColor Yellow
            return "rollback"
        }
        "c" {
            Write-Host "[INFO] Process canceled by user." -ForegroundColor Yellow
            return "cancel"
        }
        default {
            Write-Host "[WARN] Invalid choice. Defaulting to continue." -ForegroundColor Yellow
            return "continue"
        }
    }
}
