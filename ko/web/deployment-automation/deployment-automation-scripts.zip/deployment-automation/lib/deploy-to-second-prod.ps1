function Deploy-ToSecondProd {
    param (
        [string]$project,
        [string]$env,
        [string]$warPath,
        [string]$projectPath
    )

    Write-Host "`n[CLOSE] Please close PuTTY sessions for the previous prod environment and Amazon Server - local." -ForegroundColor Cyan
    pause

    Write-Host "`n[INFO] Starting deployment for '$project' to $env..." -ForegroundColor Cyan

    Launch-PuttySessionsForDeployment -project $project -env $env

    Verify-WarFile -project $project -projectPath $projectPath

    $backupFilename = Run-WinSCPDeployment -project $project -env $env -warPath $warPath
    if (-not $backupFilename) {
        Write-Host "[WARN] No backup filename returned. Rollback may not work." -ForegroundColor Yellow
    }

    $ranPuttyCommands = $false
    $puttyPrompt = Read-Host "`n[PUTTY] Run Tomcat restart and log commands in PuTTY for '$project' in '$env'? (y/n)"
    if ($puttyPrompt.ToLower() -eq 'y') {
        Send-TomcatRestartAndLogs -sessionName "Amazon Server - local"
        $ranPuttyCommands = $true
    } else {
        Write-Host "[INFO] Skipping PuTTY Tomcat and log commands."
    }

    Run-PostChecksAndRollback -project $project -env $env -backupFilename $backupFilename -ranPuttyCommands $ranPuttyCommands
}
