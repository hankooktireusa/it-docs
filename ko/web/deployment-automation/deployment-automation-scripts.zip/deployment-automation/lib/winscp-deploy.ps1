function Run-WinSCPDeployment {
    param (
        [string]$project,
        [string]$env,
        [string]$warPath
    )

    # === Get WinSCP host key directly from config ===
    $key = "${project}_${env}"
    $hostKeyForWinSCP = $trustedHostKeys[$key].winscp
    Write-Host "[INFO] Using WinSCP fingerprint: $hostKeyForWinSCP" -ForegroundColor Cyan

    # Write-Host "`n[WINSCP] Ready to upload WAR for '$project' in '$env'."
    Write-Host ""
    Write-Host "[WINSCP] Ready to upload WAR for '" -NoNewline
    Write-Host $project -ForegroundColor Cyan -NoNewline
    Write-Host "' in '" -NoNewline
    Write-Host $env -ForegroundColor Yellow -NoNewline
    Write-Host "'."
    $confirm = Read-Host "Proceed with WAR upload using WinSCP? (y/n)"
    if ($confirm.ToLower() -ne 'y') {
        Write-Host "[SKIPPED] WinSCP upload step skipped."
        return
    }

    # === Paths ===
    $remoteWebappsPath = "/opt/tomcat/webapps"
    $remoteRootWar = "$remoteWebappsPath/ROOT.war"
    $remoteWarFolder = "$remoteWebappsPath/WAR"
    $localSnapshotName = Split-Path $warPath -Leaf

    # === SSH details ===
    $key = "${project}_${env}"
    $privateKeyPath = "C:\Users\Steven.Dunning\Documents\keys\hankooktire-us-key.ppk"
    $openCommand = "open sftp://ec2-user@localhost/ -hostkey=`"$hostKeyForWinSCP`" -privatekey=`"$privateKeyPath`" -rawsettings AuthGSSAPIKEX=1"

    # === Step 1: Upload WAR file ===
    $uploadScript = @"
option batch abort
option confirm off
$openCommand

put `"$warPath`" `"$remoteWarFolder/`"

exit
"@
    $tempUploadScript = "$env:TEMP\winscp_upload.txt"
    $uploadScript | Out-File -Encoding ASCII -FilePath $tempUploadScript
    Start-Process -FilePath "winscp.com" -ArgumentList "/script=`"$tempUploadScript`"" -Wait -NoNewWindow

    # === Step 2: Get ROOT.war last modified date ===
    $lsScript = @"
option batch abort
option confirm off
$openCommand

ls $remoteWebappsPath

exit
"@
    $tempLsScript = "$env:TEMP\winscp_ls.txt"
    $lsScript | Out-File -Encoding ASCII -FilePath $tempLsScript
    $lsOutput = & "winscp.com" "/script=$tempLsScript"

    $backupFilename = $null
    $rootLine = $lsOutput | Where-Object { $_ -match "ROOT\.war" }
    if ($rootLine -match "\w+\s+\d+\s+\d+:\d+.*ROOT\.war") {
        $tokens = $rootLine -split '\s+'
        $month = $tokens[5]
        $day = $tokens[6].PadLeft(2, '0')
        $year = (Get-Date).Year.ToString()
        $monthNum = [datetime]::ParseExact($month, 'MMM', $null).Month.ToString("D2")
        $backupDate = "$year-$monthNum-$day"
        $backupYYMMDD = (Get-Date $backupDate).ToString("yyMMdd")
        $backupFilename = "ROOT$backupYYMMDD.war"

        # === Step 2a: Download ROOT.war to local backup ===
        $downloadFolder = Join-Path "$env:USERPROFILE\Downloads" "deployment-backup"
        if (-not (Test-Path $downloadFolder)) {
            New-Item -ItemType Directory -Path $downloadFolder | Out-Null
        }

        $downloadScript = @"
option batch abort
option confirm off
$openCommand

get $remoteRootWar `"$downloadFolder\ROOT_original.war`"

exit
"@
        $tempDownloadScript = "$env:TEMP\winscp_download.txt"
        $downloadScript | Out-File -Encoding ASCII -FilePath $tempDownloadScript
        $null = & "winscp.com" "/script=$tempDownloadScript"

        $noteFile = Join-Path $downloadFolder "backup_info.txt"
        "This ROOT.war will be renamed on the server as: $backupFilename" | Out-File -FilePath $noteFile -Encoding UTF8

        Write-Host "[INFO] Original ROOT.war downloaded to: $downloadFolder\ROOT_original.war"
        Write-Host "[INFO] Backup info saved to: $noteFile"

        # === Step 3: Rename ROOT.war on server ===
        $renameScript = @"
option batch abort
option confirm off
$openCommand

mv $remoteRootWar $remoteWarFolder/$backupFilename

exit
"@
        $tempRenameScript = "$env:TEMP\winscp_rename.txt"
        $renameScript | Out-File -Encoding ASCII -FilePath $tempRenameScript
        $null = & "winscp.com" "/script=$tempRenameScript"

        Write-Host "`n[INFO] ROOT.war successfully moved to $backupFilename"

        # === Step 4: Finalize deployment ===
        $finalizeScript = @"
option batch abort
option confirm off
$openCommand

mv $remoteWarFolder/$localSnapshotName $remoteWebappsPath/ROOT.war

exit
"@
        $tempFinalizeScript = "$env:TEMP\winscp_finalize.txt"
        $finalizeScript | Out-File -Encoding ASCII -FilePath $tempFinalizeScript
        $null = & "winscp.com" "/script=$tempFinalizeScript"

        Write-Host "[INFO] New WAR file deployed as ROOT.war"

        return $backupFilename
    } else {
        Write-Host "[WARN] Could not determine ROOT.war last modified time."
        return $null
    }
}
