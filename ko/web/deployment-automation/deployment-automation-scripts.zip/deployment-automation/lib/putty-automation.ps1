# ======================================================
# === SEND TOMCAT RESTART AND LOG COMMANDS TO PUTTY ====
# ======================================================

function Send-TomcatRestartAndLogs {
    param (
        [string]$sessionName  # Example: "Amazon Server - local"
    )

    # Load required assembly for SendKeys
    Add-Type -AssemblyName System.Windows.Forms

    # Locate the PuTTY window
    $puttyWindow = (Get-Process putty -ErrorAction SilentlyContinue | Where-Object {
        $_.MainWindowTitle -like "*$sessionName*"
    }) | Select-Object -First 1

    if (-not $puttyWindow) {
        Write-Host "[ERROR] Could not find PuTTY session window with title: $sessionName" -ForegroundColor Red
        return
    }

    # Bring PuTTY window to the foreground
    $signature = @'
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
'@
    Add-Type -MemberDefinition $signature -Name "Win32SetForegroundWindow" -Namespace Win32Functions -ErrorAction SilentlyContinue

    [Win32Functions.Win32SetForegroundWindow]::SetForegroundWindow($puttyWindow.MainWindowHandle) | Out-Null
    Start-Sleep -Milliseconds 500

    # Type Tomcat restart and Catalina log commands
    [System.Windows.Forms.SendKeys]::SendWait("sudo service tomcat restart{ENTER}")
    Start-Sleep -Seconds 2
    [System.Windows.Forms.SendKeys]::SendWait("tail -f /opt/tomcat/logs/catalina.out{ENTER}")

    Write-Host "[INFO] Tomcat restart and log monitoring commands sent to PuTTY session: $sessionName" -ForegroundColor Green
}
